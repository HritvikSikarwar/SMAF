package com.instant.hritvik.smaf;

/*   public class followerschartActivity extends AppCompatActivity {

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_followerschart);
            ChartFragment fragment = new ChartFragment();
            FragmentManager manager = getSupportFragmentManager();
            manager.beginTransaction().add(R.id.follwers_bar_chart_btn,new followerschartActivity()).commit();

        }
    }*/
